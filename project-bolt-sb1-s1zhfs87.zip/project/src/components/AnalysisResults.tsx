import React from 'react';
import { 
  Leaf, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  MapPin,
  Thermometer
} from 'lucide-react';
import { CropAnalysis } from '../types';

interface AnalysisResultsProps {
  analysis: CropAnalysis;
  imageUrl: string;
}

const AnalysisResults: React.FC<AnalysisResultsProps> = ({ analysis, imageUrl }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-blue-600 bg-blue-100';
      default: return 'text-green-600 bg-green-100';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return <AlertTriangle size={20} />;
      case 'medium': return <AlertTriangle size={20} />;
      case 'low': return <AlertTriangle size={20} />;
      default: return <CheckCircle size={20} />;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Analysis Results</h2>
        <p className="text-gray-600">AI-powered crop health assessment</p>
      </div>

      {/* Main Results Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Image Display */}
        <div className="space-y-4">
          <img
            src={imageUrl}
            alt="Analyzed crop"
            className="w-full rounded-xl shadow-lg"
          />
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
            <Clock size={16} />
            <span>Analyzed: {new Date(analysis.timestamp).toLocaleString()}</span>
          </div>
        </div>

        {/* Analysis Details */}
        <div className="space-y-4">
          {/* Crop Type */}
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-2">
              <Leaf className="text-green-600" size={20} />
              <h3 className="font-semibold text-gray-900">Crop Identification</h3>
            </div>
            <p className="text-lg font-medium text-gray-800">{analysis.cropType}</p>
            <p className="text-sm text-gray-600">Confidence: {analysis.cropConfidence}%</p>
          </div>

          {/* Disease Detection */}
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-2">
              <div className={`p-1 rounded-full ${getSeverityColor(analysis.severity)}`}>
                {getSeverityIcon(analysis.severity)}
              </div>
              <h3 className="font-semibold text-gray-900">Health Status</h3>
            </div>
            <p className="text-lg font-medium text-gray-800">{analysis.disease}</p>
            <p className="text-sm text-gray-600">Confidence: {analysis.diseaseConfidence}%</p>
            <div className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-2 ${getSeverityColor(analysis.severity)}`}>
              {analysis.severity === 'none' ? 'Healthy' : `${analysis.severity.charAt(0).toUpperCase() + analysis.severity.slice(1)} Severity`}
            </div>
          </div>

          {/* Yield Estimation */}
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center space-x-3 mb-2">
              <TrendingUp className="text-blue-600" size={20} />
              <h3 className="font-semibold text-gray-900">Yield Estimate</h3>
            </div>
            <p className="text-lg font-medium text-gray-800">
              {analysis.yieldEstimate} {analysis.yieldUnit}
            </p>
            <p className="text-sm text-gray-600">Based on current crop condition</p>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl border border-green-200">
        <h3 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
          <Thermometer className="text-green-600" size={20} />
          <span>Recommended Actions</span>
        </h3>
        <p className="text-gray-800 leading-relaxed">{analysis.recommendation}</p>
      </div>

      {/* Additional Information */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm text-center">
          <div className="text-2xl font-bold text-blue-600 mb-1">{analysis.cropConfidence}%</div>
          <div className="text-sm text-gray-600">Crop ID Accuracy</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm text-center">
          <div className="text-2xl font-bold text-green-600 mb-1">{analysis.diseaseConfidence}%</div>
          <div className="text-sm text-gray-600">Disease Detection</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm text-center">
          <div className="text-2xl font-bold text-purple-600 mb-1">
            {analysis.yieldEstimate}
          </div>
          <div className="text-sm text-gray-600">Tons per Acre</div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200">
          Save Analysis
        </button>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200">
          Share with Expert
        </button>
        <button className="border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-lg font-medium transition-colors duration-200">
          Analyze Another Image
        </button>
      </div>
    </div>
  );
};

export default AnalysisResults;