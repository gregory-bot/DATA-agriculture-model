import React from 'react';
import { 
  Eye, 
  TrendingUp, 
  MessageSquare, 
  Shield, 
  Zap, 
  Globe 
} from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Eye size={24} />,
      title: 'Disease Detection',
      description: 'Advanced AI identifies crop diseases with 95% accuracy from drone or mobile images.',
      color: 'text-red-500 bg-red-100'
    },
    {
      icon: <TrendingUp size={24} />,
      title: 'Yield Estimation',
      description: 'Predict crop yields per acre using satellite and drone imagery analysis.',
      color: 'text-green-500 bg-green-100'
    },
    {
      icon: <MessageSquare size={24} />,
      title: 'Smart Recommendations',
      description: 'Get actionable advice in simple language for treatment and intervention.',
      color: 'text-blue-500 bg-blue-100'
    },
    {
      icon: <Shield size={24} />,
      title: 'Multi-Crop Support',
      description: 'Works with corn, wheat, rice, tomatoes, and other major crop varieties.',
      color: 'text-purple-500 bg-purple-100'
    },
    {
      icon: <Zap size={24} />,
      title: 'Real-time Analysis',
      description: 'Get instant results with confidence scores and severity assessments.',
      color: 'text-yellow-500 bg-yellow-100'
    },
    {
      icon: <Globe size={24} />,
      title: 'Offline Capable',
      description: 'Lightweight model works even in areas with limited internet connectivity.',
      color: 'text-indigo-500 bg-indigo-100'
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Powerful AI Features for Modern Agriculture
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our computer vision technology helps smallholder farmers make informed decisions 
            about crop health, disease management, and yield optimization.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <div className={`inline-flex p-3 rounded-lg ${feature.color} mb-4`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Technical Specifications */}
        <div className="mt-16 bg-white p-8 rounded-xl shadow-md">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Technical Specifications
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">95%+</div>
              <div className="text-sm text-gray-600">Disease Detection Accuracy</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">8+</div>
              <div className="text-sm text-gray-600">Supported Crop Types</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">20+</div>
              <div className="text-sm text-gray-600">Disease Classifications</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">&lt;3s</div>
              <div className="text-sm text-gray-600">Analysis Time</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;