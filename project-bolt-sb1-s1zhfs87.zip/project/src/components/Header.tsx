import React from 'react';
import { Leaf, Brain, Smartphone } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 text-white shadow-lg">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <Leaf size={32} className="text-green-200" />
              <Brain size={32} className="text-blue-200" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">AgriVision AI</h1>
              <p className="text-sm text-green-100">Smart Crop Monitoring System</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <div className="text-center">
              <div className="text-lg font-semibold">10,000+</div>
              <div className="text-xs text-green-100">Farmers Helped</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold">95%</div>
              <div className="text-xs text-blue-100">Accuracy Rate</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold">24/7</div>
              <div className="text-xs text-purple-100">AI Support</div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Smartphone size={20} />
            <span className="text-sm">Mobile Ready</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;