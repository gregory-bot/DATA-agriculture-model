import React from 'react';
import { ChevronDown, Github, Linkedin, Mail } from 'lucide-react';

interface HeroProps {
  darkMode: boolean;
}

const Hero: React.FC<HeroProps> = ({ darkMode }) => {
  const scrollToAbout = () => {
    const aboutSection = document.querySelector('#about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className={`min-h-screen flex items-center justify-center relative overflow-hidden ${
        darkMode
          ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900'
          : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
      }`}
    >
      <div className="container mx-auto px-6 text-center z-10">
        <div className="mb-8">
          <div
            className={`w-48 h-48 mx-auto rounded-full mb-8 bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center text-6xl font-bold text-white shadow-2xl`}
          >
            GK
          </div>
        </div>

        <h1
          className={`text-5xl md:text-7xl font-bold mb-6 ${
            darkMode ? 'text-white' : 'text-gray-900'
          }`}
        >
          Gregory Kipngeno
        </h1>

        <p
          className={`text-xl md:text-2xl mb-8 ${
            darkMode ? 'text-gray-300' : 'text-gray-600'
          }`}
        >
          Full Stack Developer & UI/UX Designer
        </p>

        <p
          className={`text-lg mb-12 max-w-2xl mx-auto ${
            darkMode ? 'text-gray-400' : 'text-gray-700'
          }`}
        >
          Passionate about creating beautiful, functional, and user-centered
          digital experiences. I bring ideas to life through clean code and
          thoughtful design.
        </p>

        <div className="flex justify-center space-x-6 mb-12">
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${
              darkMode
                ? 'bg-gray-800 hover:bg-gray-700 text-white'
                : 'bg-white hover:bg-gray-50 text-gray-700 shadow-lg'
            }`}
          >
            <Github size={24} />
          </a>
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${
              darkMode
                ? 'bg-gray-800 hover:bg-gray-700 text-white'
                : 'bg-white hover:bg-gray-50 text-gray-700 shadow-lg'
            }`}
          >
            <Linkedin size={24} />
          </a>
          <a
            href="mailto:gregory@example.com"
            className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${
              darkMode
                ? 'bg-gray-800 hover:bg-gray-700 text-white'
                : 'bg-white hover:bg-gray-50 text-gray-700 shadow-lg'
            }`}
          >
            <Mail size={24} />
          </a>
        </div>

        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <button
            onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
          >
            View My Work
          </button>
          <button
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className={`px-8 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 border-2 ${
              darkMode
                ? 'border-gray-400 text-gray-300 hover:bg-gray-800'
                : 'border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            Get In Touch
          </button>
        </div>
      </div>

      <button
        onClick={scrollToAbout}
        className={`absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce ${
          darkMode ? 'text-gray-400' : 'text-gray-500'
        }`}
      >
        <ChevronDown size={32} />
      </button>

      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute -top-40 -right-40 w-80 h-80 rounded-full opacity-20 ${
            darkMode ? 'bg-blue-500' : 'bg-blue-300'
          }`}
        />
        <div
          className={`absolute -bottom-40 -left-40 w-80 h-80 rounded-full opacity-20 ${
            darkMode ? 'bg-purple-500' : 'bg-purple-300'
          }`}
        />
      </div>
    </section>
  );
};

export default Hero;