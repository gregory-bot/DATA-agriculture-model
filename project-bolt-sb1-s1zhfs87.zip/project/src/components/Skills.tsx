import React from 'react';
import { 
  Code2, 
  Database, 
  Palette, 
  Smartphone, 
  Globe, 
  Server 
} from 'lucide-react';

interface SkillsProps {
  darkMode: boolean;
}

const Skills: React.FC<SkillsProps> = ({ darkMode }) => {
  const skillCategories = [
    {
      icon: <Code2 size={24} />,
      title: 'Frontend Development',
      skills: [
        { name: 'React/Next.js', level: 95 },
        { name: 'TypeScript', level: 90 },
        { name: 'Tailwind CSS', level: 95 },
        { name: 'JavaScript', level: 92 },
      ],
    },
    {
      icon: <Server size={24} />,
      title: 'Backend Development',
      skills: [
        { name: 'Node.js', level: 88 },
        { name: 'Python', level: 85 },
        { name: 'REST APIs', level: 92 },
        { name: 'GraphQL', level: 80 },
      ],
    },
    {
      icon: <Database size={24} />,
      title: 'Database & Tools',
      skills: [
        { name: 'PostgreSQL', level: 85 },
        { name: 'MongoDB', level: 82 },
        { name: 'Docker', level: 80 },
        { name: 'AWS', level: 75 },
      ],
    },
    {
      icon: <Palette size={24} />,
      title: 'Design & UX',
      skills: [
        { name: 'Figma', level: 90 },
        { name: 'Adobe XD', level: 85 },
        { name: 'UI/UX Design', level: 88 },
        { name: 'Prototyping', level: 85 },
      ],
    },
  ];

  return (
    <section
      id="skills"
      className={`py-20 ${
        darkMode ? 'bg-gray-800' : 'bg-white'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2
            className={`text-4xl md:text-5xl font-bold mb-4 ${
              darkMode ? 'text-white' : 'text-gray-900'
            }`}
          >
            Skills & Expertise
          </h2>
          <p
            className={`text-xl ${
              darkMode ? 'text-gray-400' : 'text-gray-600'
            }`}
          >
            Technologies and tools I work with
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className={`p-8 rounded-2xl transition-all duration-300 hover:scale-105 ${
                darkMode
                  ? 'bg-gray-700 hover:bg-gray-600'
                  : 'bg-gray-50 hover:bg-gray-100 shadow-lg'
              }`}
            >
              <div className="flex items-center mb-6">
                <div className="text-blue-600 mr-4">{category.icon}</div>
                <h3
                  className={`text-xl font-bold ${
                    darkMode ? 'text-white' : 'text-gray-900'
                  }`}
                >
                  {category.title}
                </h3>
              </div>

              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between mb-2">
                      <span
                        className={`text-sm font-medium ${
                          darkMode ? 'text-gray-300' : 'text-gray-700'
                        }`}
                      >
                        {skill.name}
                      </span>
                      <span
                        className={`text-sm font-medium ${
                          darkMode ? 'text-gray-400' : 'text-gray-500'
                        }`}
                      >
                        {skill.level}%
                      </span>
                    </div>
                    <div
                      className={`w-full rounded-full h-2 ${
                        darkMode ? 'bg-gray-600' : 'bg-gray-200'
                      }`}
                    >
                      <div
                        className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;