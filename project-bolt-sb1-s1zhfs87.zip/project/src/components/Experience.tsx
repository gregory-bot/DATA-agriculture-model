import React from 'react';
import { Calendar, MapPin } from 'lucide-react';

interface ExperienceProps {
  darkMode: boolean;
}

const Experience: React.FC<ExperienceProps> = ({ darkMode }) => {
  const experiences = [
    {
      title: 'Senior Full Stack Developer',
      company: 'TechCorp Solutions',
      location: 'Nairobi, Kenya',
      period: '2022 - Present',
      description: [
        'Led development of scalable web applications serving 100k+ users',
        'Mentored junior developers and established coding standards',
        'Implemented CI/CD pipelines reducing deployment time by 60%',
        'Collaborated with cross-functional teams to deliver features on time',
      ],
    },
    {
      title: 'Frontend Developer',
      company: 'Digital Innovations Ltd',
      location: 'Nairobi, Kenya',
      period: '2020 - 2022',
      description: [
        'Developed responsive web applications using React and TypeScript',
        'Improved application performance by 40% through optimization',
        'Collaborated with designers to implement pixel-perfect UI components',
        'Maintained and refactored legacy codebases',
      ],
    },
    {
      title: 'Junior Web Developer',
      company: 'StartupHub Kenya',
      location: 'Nairobi, Kenya',
      period: '2019 - 2020',
      description: [
        'Built and maintained company websites using modern web technologies',
        'Worked closely with the design team to implement user interfaces',
        'Participated in code reviews and team development processes',
        'Gained experience in full-stack development fundamentals',
      ],
    },
    {
      title: 'Web Development Intern',
      company: 'CodeCraft Academy',
      location: 'Nairobi, Kenya',
      period: '2018 - 2019',
      description: [
        'Completed intensive web development bootcamp program',
        'Built several projects using HTML, CSS, JavaScript, and React',
        'Learned software development best practices and methodologies',
        'Collaborated on team projects and learned version control with Git',
      ],
    },
  ];

  return (
    <section
      id="experience"
      className={`py-20 ${
        darkMode ? 'bg-gray-800' : 'bg-white'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2
            className={`text-4xl md:text-5xl font-bold mb-4 ${
              darkMode ? 'text-white' : 'text-gray-900'
            }`}
          >
            Work Experience
          </h2>
          <p
            className={`text-xl ${
              darkMode ? 'text-gray-400' : 'text-gray-600'
            }`}
          >
            My professional journey
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {experiences.map((exp, index) => (
            <div key={index} className="relative">
              {/* Timeline line */}
              {index !== experiences.length - 1 && (
                <div
                  className={`absolute left-8 top-16 w-0.5 h-32 ${
                    darkMode ? 'bg-gray-600' : 'bg-gray-300'
                  }`}
                />
              )}

              <div className="flex items-start mb-12">
                {/* Timeline dot */}
                <div className="flex-shrink-0 w-4 h-4 bg-blue-600 rounded-full mt-6 mr-8 relative z-10" />

                <div
                  className={`flex-1 p-6 rounded-2xl transition-all duration-300 hover:scale-105 ${
                    darkMode
                      ? 'bg-gray-700 hover:bg-gray-600'
                      : 'bg-gray-50 hover:bg-gray-100 shadow-lg hover:shadow-xl'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h3
                        className={`text-xl font-bold mb-1 ${
                          darkMode ? 'text-white' : 'text-gray-900'
                        }`}
                      >
                        {exp.title}
                      </h3>
                      <p className="text-blue-600 font-semibold mb-2">
                        {exp.company}
                      </p>
                    </div>
                    <div className="flex flex-col md:items-end space-y-1">
                      <div
                        className={`flex items-center space-x-1 text-sm ${
                          darkMode ? 'text-gray-400' : 'text-gray-600'
                        }`}
                      >
                        <Calendar size={14} />
                        <span>{exp.period}</span>
                      </div>
                      <div
                        className={`flex items-center space-x-1 text-sm ${
                          darkMode ? 'text-gray-400' : 'text-gray-600'
                        }`}
                      >
                        <MapPin size={14} />
                        <span>{exp.location}</span>
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-2">
                    {exp.description.map((item, itemIndex) => (
                      <li
                        key={itemIndex}
                        className={`flex items-start space-x-2 ${
                          darkMode ? 'text-gray-300' : 'text-gray-700'
                        }`}
                      >
                        <span className="text-blue-600 mt-1.5 flex-shrink-0">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;