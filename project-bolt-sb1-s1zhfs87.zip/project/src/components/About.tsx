import React from 'react';
import { Code, Palette, Zap } from 'lucide-react';

interface AboutProps {
  darkMode: boolean;
}

const About: React.FC<AboutProps> = ({ darkMode }) => {
  const highlights = [
    {
      icon: <Code size={24} />,
      title: 'Clean Code',
      description: 'Writing maintainable, scalable, and efficient code is my passion.',
    },
    {
      icon: <Palette size={24} />,
      title: 'Design Thinking',
      description: 'User-centered design approach to create meaningful experiences.',
    },
    {
      icon: <Zap size={24} />,
      title: 'Performance',
      description: 'Optimizing for speed and accessibility in every project.',
    },
  ];

  return (
    <section
      id="about"
      className={`py-20 ${
        darkMode ? 'bg-gray-900' : 'bg-gray-50'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2
            className={`text-4xl md:text-5xl font-bold mb-4 ${
              darkMode ? 'text-white' : 'text-gray-900'
            }`}
          >
            About Me
          </h2>
          <p
            className={`text-xl ${
              darkMode ? 'text-gray-400' : 'text-gray-600'
            }`}
          >
            Passionate developer with a love for creating amazing experiences
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div
              className={`w-full h-96 rounded-2xl bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center text-8xl font-bold text-white shadow-2xl`}
            >
              GK
            </div>
          </div>

          <div>
            <p
              className={`text-lg mb-6 leading-relaxed ${
                darkMode ? 'text-gray-300' : 'text-gray-700'
              }`}
            >
              Hi, I'm Gregory Kipngeno, a passionate full-stack developer and UI/UX designer 
              with over 5 years of experience creating digital solutions that make a difference. 
              I specialize in modern web technologies and have a keen eye for design.
            </p>

            <p
              className={`text-lg mb-8 leading-relaxed ${
                darkMode ? 'text-gray-300' : 'text-gray-700'
              }`}
            >
              When I'm not coding, you'll find me exploring new technologies, contributing to 
              open-source projects, or mentoring aspiring developers. I believe in continuous 
              learning and staying up-to-date with the latest industry trends.
            </p>

            <div className="grid gap-6">
              {highlights.map((highlight, index) => (
                <div
                  key={index}
                  className={`flex items-start space-x-4 p-4 rounded-lg transition-all duration-300 hover:scale-105 ${
                    darkMode
                      ? 'bg-gray-800 hover:bg-gray-700'
                      : 'bg-white hover:bg-gray-50 shadow-md'
                  }`}
                >
                  <div className="text-blue-600 mt-1">{highlight.icon}</div>
                  <div>
                    <h3
                      className={`font-semibold mb-2 ${
                        darkMode ? 'text-white' : 'text-gray-900'
                      }`}
                    >
                      {highlight.title}
                    </h3>
                    <p
                      className={darkMode ? 'text-gray-400' : 'text-gray-600'}
                    >
                      {highlight.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;