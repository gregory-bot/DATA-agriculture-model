import React from 'react';
import { Heart } from 'lucide-react';

interface FooterProps {
  darkMode: boolean;
}

const Footer: React.FC<FooterProps> = ({ darkMode }) => {
  return (
    <footer
      className={`py-8 border-t ${
        darkMode
          ? 'bg-gray-800 border-gray-700'
          : 'bg-white border-gray-200'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-4 md:mb-0">
            <p
              className={`flex items-center space-x-2 ${
                darkMode ? 'text-gray-400' : 'text-gray-600'
              }`}
            >
              <span>Made with</span>
              <Heart size={16} className="text-red-500" />
              <span>by Gregory Kipngeno</span>
            </p>
          </div>
          
          <div>
            <p
              className={`text-sm ${
                darkMode ? 'text-gray-400' : 'text-gray-600'
              }`}
            >
              © {new Date().getFullYear()} Gregory Kipngeno. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;