import React from 'react';
import { Loader2, Brain, Leaf } from 'lucide-react';

interface LoadingSpinnerProps {
  message?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  message = "Analyzing your crop image..." 
}) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 space-y-6">
      {/* Animated Icons */}
      <div className="relative">
        <div className="flex items-center space-x-4">
          <div className="animate-pulse">
            <Leaf size={32} className="text-green-500" />
          </div>
          <div className="animate-spin">
            <Brain size={32} className="text-blue-500" />
          </div>
          <div className="animate-bounce">
            <Loader2 size={32} className="text-purple-500" />
          </div>
        </div>
      </div>

      {/* Loading Message */}
      <div className="text-center space-y-2">
        <h3 className="text-lg font-semibold text-gray-800">{message}</h3>
        <p className="text-sm text-gray-600">
          Our AI is examining your crop for diseases and estimating yield...
        </p>
      </div>

      {/* Progress Steps */}
      <div className="w-full max-w-md space-y-3">
        <div className="flex items-center space-x-3">
          <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-700">Identifying crop type</span>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
          <span className="text-sm text-gray-700">Detecting diseases</span>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-4 h-4 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
          <span className="text-sm text-gray-700">Estimating yield</span>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-4 h-4 bg-orange-500 rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
          <span className="text-sm text-gray-700">Generating recommendations</span>
        </div>
      </div>

      {/* Loading Bar */}
      <div className="w-full max-w-md bg-gray-200 rounded-full h-2">
        <div className="bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 h-2 rounded-full animate-pulse"></div>
      </div>
    </div>
  );
};

export default LoadingSpinner;