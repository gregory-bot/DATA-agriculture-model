// Data processing utilities for agricultural AI training
export interface TrainingData {
  imagePath: string;
  cropType: string;
  disease: string;
  severity: 'none' | 'low' | 'medium' | 'high';
  yieldEstimate?: number;
  location?: string;
  date?: string;
  boundingBoxes?: BoundingBox[];
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
  label: string;
  confidence: number;
}

export class DataProcessor {
  static validateDataset(data: TrainingData[]): {
    valid: boolean;
    errors: string[];
    stats: DatasetStats;
  } {
    const errors: string[] = [];
    const stats: DatasetStats = {
      totalImages: data.length,
      cropTypes: new Set(),
      diseases: new Set(),
      severityDistribution: { none: 0, low: 0, medium: 0, high: 0 }
    };

    data.forEach((item, index) => {
      // Validate required fields
      if (!item.imagePath) errors.push(`Row ${index}: Missing image path`);
      if (!item.cropType) errors.push(`Row ${index}: Missing crop type`);
      if (!item.disease) errors.push(`Row ${index}: Missing disease`);
      
      // Collect statistics
      stats.cropTypes.add(item.cropType);
      stats.diseases.add(item.disease);
      stats.severityDistribution[item.severity]++;
    });

    return {
      valid: errors.length === 0,
      errors,
      stats: {
        ...stats,
        cropTypes: Array.from(stats.cropTypes),
        diseases: Array.from(stats.diseases)
      }
    };
  }

  static generateTrainingConfig(data: TrainingData[]): TrainingConfig {
    const validation = this.validateDataset(data);
    
    return {
      modelArchitecture: 'EfficientNetB0',
      inputSize: [224, 224, 3],
      numCropClasses: validation.stats.cropTypes.length,
      numDiseaseClasses: validation.stats.diseases.length,
      batchSize: 32,
      epochs: 50,
      learningRate: 0.001,
      augmentation: {
        rotation: 20,
        zoom: 0.2,
        horizontalFlip: true,
        brightness: 0.2
      },
      splitRatio: {
        train: 0.8,
        validation: 0.1,
        test: 0.1
      }
    };
  }

  static exportForTraining(data: TrainingData[], format: 'tensorflow' | 'pytorch' | 'yolo'): string {
    switch (format) {
      case 'tensorflow':
        return this.exportTensorFlowFormat(data);
      case 'pytorch':
        return this.exportPyTorchFormat(data);
      case 'yolo':
        return this.exportYOLOFormat(data);
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
  }

  private static exportTensorFlowFormat(data: TrainingData[]): string {
    const tfData = data.map(item => ({
      image_path: item.imagePath,
      crop_label: item.cropType,
      disease_label: item.disease,
      severity_score: this.severityToScore(item.severity),
      yield_estimate: item.yieldEstimate || 0
    }));

    return JSON.stringify(tfData, null, 2);
  }

  private static exportPyTorchFormat(data: TrainingData[]): string {
    // PyTorch dataset format
    const pytorchData = {
      annotations: data.map((item, index) => ({
        id: index,
        image_path: item.imagePath,
        crop_type: item.cropType,
        disease: item.disease,
        severity: item.severity,
        yield_estimate: item.yieldEstimate,
        bounding_boxes: item.boundingBoxes || []
      })),
      categories: {
        crops: Array.from(new Set(data.map(d => d.cropType))),
        diseases: Array.from(new Set(data.map(d => d.disease)))
      }
    };

    return JSON.stringify(pytorchData, null, 2);
  }

  private static exportYOLOFormat(data: TrainingData[]): string {
    // YOLO format for object detection
    const yoloData = data.map(item => {
      const annotations = item.boundingBoxes?.map(box => 
        `${box.label} ${box.x} ${box.y} ${box.width} ${box.height}`
      ).join('\n') || '';
      
      return {
        image: item.imagePath,
        annotations: annotations
      };
    });

    return JSON.stringify(yoloData, null, 2);
  }

  private static severityToScore(severity: string): number {
    const scoreMap = { none: 0, low: 0.33, medium: 0.66, high: 1.0 };
    return scoreMap[severity as keyof typeof scoreMap] || 0;
  }
}

interface DatasetStats {
  totalImages: number;
  cropTypes: string[] | Set<string>;
  diseases: string[] | Set<string>;
  severityDistribution: {
    none: number;
    low: number;
    medium: number;
    high: number;
  };
}

interface TrainingConfig {
  modelArchitecture: string;
  inputSize: number[];
  numCropClasses: number;
  numDiseaseClasses: number;
  batchSize: number;
  epochs: number;
  learningRate: number;
  augmentation: {
    rotation: number;
    zoom: number;
    horizontalFlip: boolean;
    brightness: number;
  };
  splitRatio: {
    train: number;
    validation: number;
    test: number;
  };
}