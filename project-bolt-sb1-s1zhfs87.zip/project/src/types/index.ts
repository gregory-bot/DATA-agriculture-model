export interface CropAnalysis {
  cropType: string;
  cropConfidence: number;
  disease: string;
  diseaseConfidence: number;
  yieldEstimate: number;
  yieldUnit: string;
  recommendation: string;
  severity: 'low' | 'medium' | 'high' | 'none';
  detectedRegions?: BoundingBox[];
  timestamp: string;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
  label: string;
}

export interface ModelPrediction {
  className: string;
  probability: number;
}

export interface AnalysisHistory {
  id: string;
  analysis: CropAnalysis;
  imageUrl: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

export interface FarmerProfile {
  name: string;
  location: string;
  cropTypes: string[];
  farmSize: number;
  contactInfo: string;
}