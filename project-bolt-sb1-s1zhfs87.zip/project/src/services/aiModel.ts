import { CropAnalysis } from '../types';

class AgriculturalAIModel {
  private isLoaded = false;
  private loadingProgress = 0;
  
  // API Configuration - Using environment variables
  private apiConfig = {
    // Plant.id API - Excellent for plant disease identification
    plantid: {
      key: import.meta.env.VITE_PLANT_ID_API_KEY || '',
      endpoint: 'https://api.plant.id/v3/identification',
      active: true,
      priority: 1 // Highest priority
    },
    
    // Roboflow API - Great for custom crop models
    roboflow: {
      key: import.meta.env.VITE_ROBOFLOW_API_KEY || '',
      endpoint: 'https://detect.roboflow.com/leaf_disease_detection-yh7jo/1',
      active: true,
      priority: 2
    }
  };

  async loadModels(): Promise<void> {
    try {
      console.log('🔄 Initializing Agricultural AI System...');
      
      // Debug: Log environment variables
      console.log('Environment check:');
      console.log('VITE_PLANT_ID_API_KEY:', import.meta.env.VITE_PLANT_ID_API_KEY ? 'SET' : 'NOT SET');
      console.log('VITE_ROBOFLOW_API_KEY:', import.meta.env.VITE_ROBOFLOW_API_KEY ? 'SET' : 'NOT SET');
      
      this.loadingProgress = 25;
      await this.delay(400);
      
      // Check if any API keys are configured
      const hasPlantIdKey = this.apiConfig.plantid.key && this.apiConfig.plantid.key.length > 0;
      const hasRoboflowKey = this.apiConfig.roboflow.key && this.apiConfig.roboflow.key.length > 0;
      
      console.log('API Keys status:');
      console.log('Plant.id key available:', hasPlantIdKey);
      console.log('Roboflow key available:', hasRoboflowKey);
      
      if (!hasPlantIdKey && !hasRoboflowKey) {
        throw new Error('No API keys configured. Please create a .env file in the root directory with VITE_PLANT_ID_API_KEY or VITE_ROBOFLOW_API_KEY');
      }
      
      this.loadingProgress = 60;
      await this.delay(400);
      
      // Test Plant.id connection
      let plantIdWorking = false;
      if (hasPlantIdKey) {
        console.log('Testing Plant.id connection...');
        plantIdWorking = await this.testPlantIdConnection();
        if (plantIdWorking) {
          console.log('✅ Plant.id API connected successfully!');
        } else {
          console.log('⚠️ Plant.id API not responding');
        }
      } else {
        console.log('ℹ️ Plant.id API key not configured');
      }
      
      this.loadingProgress = 80;
      await this.delay(400);
      
      // Test Roboflow connection
      let roboflowWorking = false;
      if (hasRoboflowKey) {
        console.log('Testing Roboflow connection...');
        roboflowWorking = await this.testRoboflowConnection();
        if (roboflowWorking) {
          console.log('✅ Roboflow API connected successfully!');
        } else {
          console.log('⚠️ Roboflow API not responding');
        }
      } else {
        console.log('ℹ️ Roboflow API key not configured');
      }
      
      this.loadingProgress = 90;
      await this.delay(300);
      
      // Check if at least one API is working
      const workingAPIs = [];
      if (plantIdWorking) workingAPIs.push('Plant.id');
      if (roboflowWorking) workingAPIs.push('Roboflow');
      
      if (workingAPIs.length === 0) {
        if (hasPlantIdKey || hasRoboflowKey) {
          throw new Error('API keys are configured but services are not responding. Please check your API keys are valid and you have internet connection.');
        } else {
          throw new Error('No API keys found. Please create a .env file with VITE_PLANT_ID_API_KEY or VITE_ROBOFLOW_API_KEY');
        }
      }
      
      console.log(`🎉 Active AI Services: ${workingAPIs.join(' + ')}`);
      console.log('🚀 Real AI analysis ready!');
      
      this.loadingProgress = 100;
      this.isLoaded = true;
      
    } catch (error) {
      console.error('❌ Failed to initialize AI system:', error);
      throw error;
    }
  }

  private async testPlantIdConnection(): Promise<boolean> {
    try {
      const response = await fetch(this.apiConfig.plantid.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Api-Key': this.apiConfig.plantid.key
        },
        body: JSON.stringify({
          images: ['data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAX/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCdABmX/9k='],
          modifiers: ['health_assessment'],
          plant_details: ['common_names']
        })
      });
      
      console.log('Plant.id test response status:', response.status);
      return response.status !== 401 && response.status !== 403;
    } catch (error) {
      console.log('Plant.id connection test failed:', error);
      return false;
    }
  }

  private async testRoboflowConnection(): Promise<boolean> {
    try {
      const testUrl = `${this.apiConfig.roboflow.endpoint}?api_key=${this.apiConfig.roboflow.key}`;
      const response = await fetch(testUrl, { method: 'GET' });
      console.log('Roboflow test response status:', response.status);
      return response.status !== 401 && response.status !== 403;
    } catch (error) {
      console.log('Roboflow connection test failed:', error);
      return false;
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async analyzeImage(imageElement: HTMLImageElement): Promise<CropAnalysis> {
    if (!this.isLoaded) {
      throw new Error('AI System is not ready. Please wait for initialization to complete.');
    }

    try {
      console.log('🔍 Starting AI analysis...');
      
      // Check if any real APIs are available
      const hasPlantIdKey = this.apiConfig.plantid.key && this.apiConfig.plantid.key.length > 0;
      const hasRoboflowKey = this.apiConfig.roboflow.key && this.apiConfig.roboflow.key.length > 0;
      
      if (!hasPlantIdKey && !hasRoboflowKey) {
        throw new Error('No API keys configured. Please create a .env file with VITE_PLANT_ID_API_KEY or VITE_ROBOFLOW_API_KEY');
      }
      
      // Try Plant.id first (highest priority)
      if (hasPlantIdKey) {
        console.log('🌱 Analyzing with Plant.id API...');
        try {
          const plantIdResult = await this.analyzeWithPlantId(imageElement);
          console.log('✅ Analysis completed with Plant.id');
          return plantIdResult;
        } catch (error) {
          console.log('Plant.id analysis failed:', error);
        }
      }
      
      // Try Roboflow as backup
      if (hasRoboflowKey) {
        console.log('🤖 Analyzing with Roboflow API...');
        try {
          const roboflowResult = await this.analyzeWithRoboflow(imageElement);
          console.log('✅ Analysis completed with Roboflow');
          return roboflowResult;
        } catch (error) {
          console.log('Roboflow analysis failed:', error);
        }
      }
      
      // If we reach here, all APIs failed
      throw new Error('All AI services are currently unavailable. Please check your API keys and try again.');
      
    } catch (error) {
      console.error('❌ Error in AI analysis:', error);
      throw error;
    }
  }

  private async analyzeWithPlantId(imageElement: HTMLImageElement): Promise<CropAnalysis> {
    const base64Image = await this.imageToBase64(imageElement);
    
    const requestBody = {
      images: [`data:image/jpeg;base64,${base64Image}`],
      modifiers: ['health_assessment', 'disease_similar_images'],
      plant_details: ['common_names', 'url', 'description']
    };

    const response = await fetch(this.apiConfig.plantid.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Api-Key': this.apiConfig.plantid.key
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      throw new Error(`Plant.id API error: ${response.status} - ${response.statusText}`);
    }

    const result = await response.json();
    console.log('Plant.id response received');
    
    return this.processPlantIdResponse(result);
  }

  private processPlantIdResponse(result: any): CropAnalysis {
    const suggestions = result.suggestions || [];
    const healthAssessment = result.health_assessment || {};
    
    if (suggestions.length > 0) {
      const topSuggestion = suggestions[0];
      const plantName = topSuggestion.plant_name || 'Unknown Plant';
      const confidence = Math.round((topSuggestion.probability || 0.8) * 100);
      
      // Extract crop type from plant name
      const cropType = this.extractCropFromPlantName(plantName);
      
      // Analyze health assessment
      const diseases = healthAssessment.diseases || [];
      let disease = 'Healthy';
      let diseaseConfidence = 85;
      let severity: 'none' | 'low' | 'medium' | 'high' = 'none';
      
      if (diseases.length > 0) {
        const topDisease = diseases[0];
        disease = topDisease.name || 'Disease Detected';
        diseaseConfidence = Math.round((topDisease.probability || 0.7) * 100);
        severity = this.calculateSeverityFromConfidence(diseaseConfidence);
      }
      
      return {
        cropType: cropType,
        cropConfidence: confidence,
        disease: disease,
        diseaseConfidence: diseaseConfidence,
        yieldEstimate: this.calculateYieldFromHealth(disease, severity),
        yieldUnit: 'tons/acre',
        recommendation: this.generateTreatmentRecommendation(disease, severity, diseaseConfidence),
        severity: severity,
        timestamp: new Date().toISOString()
      };
    }
    
    throw new Error('Plant.id could not identify the plant in the image. Please try a clearer image.');
  }

  private extractCropFromPlantName(plantName: string): string {
    const cropMappings: { [key: string]: string } = {
      'corn': 'Maize/Corn',
      'maize': 'Maize/Corn',
      'zea mays': 'Maize/Corn',
      'wheat': 'Wheat',
      'triticum': 'Wheat',
      'rice': 'Rice',
      'oryza': 'Rice',
      'tomato': 'Tomato',
      'solanum lycopersicum': 'Tomato',
      'cotton': 'Cotton',
      'gossypium': 'Cotton',
      'soybean': 'Soybean',
      'glycine max': 'Soybean',
      'potato': 'Potato',
      'solanum tuberosum': 'Potato',
      'sugarcane': 'Sugarcane',
      'saccharum': 'Sugarcane'
    };
    
    const lowerName = plantName.toLowerCase();
    for (const [key, value] of Object.entries(cropMappings)) {
      if (lowerName.includes(key)) {
        return value;
      }
    }
    
    return 'Mixed Crop';
  }

  private async analyzeWithRoboflow(imageElement: HTMLImageElement): Promise<CropAnalysis> {
    const base64Image = await this.imageToBase64(imageElement);
    const url = `${this.apiConfig.roboflow.endpoint}?api_key=${this.apiConfig.roboflow.key}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: base64Image
    });

    if (!response.ok) {
      throw new Error(`Roboflow API error: ${response.status} - ${response.statusText}`);
    }

    const result = await response.json();
    return this.processRoboflowResponse(result);
  }

  private processRoboflowResponse(result: any): CropAnalysis {
    const predictions = result.predictions || [];
    
    if (predictions.length > 0) {
      const topPrediction = predictions.reduce((prev: any, current: any) => 
        (prev.confidence > current.confidence) ? prev : current
      );
      
      const diseaseClass = topPrediction.class || 'Disease Detected';
      const confidence = Math.round((topPrediction.confidence || 0.8) * 100);
      const cropType = this.extractCropFromDisease(diseaseClass);
      const standardizedDisease = this.standardizeDiseaseName(diseaseClass);
      const severity = this.calculateSeverityFromConfidence(confidence);
      
      return {
        cropType: cropType,
        cropConfidence: Math.min(confidence + 5, 99),
        disease: standardizedDisease,
        diseaseConfidence: confidence,
        yieldEstimate: this.calculateYieldFromHealth(standardizedDisease, severity),
        yieldUnit: 'tons/acre',
        recommendation: this.generateTreatmentRecommendation(standardizedDisease, severity, confidence),
        severity: severity,
        timestamp: new Date().toISOString()
      };
    }
    
    throw new Error('Roboflow could not detect any diseases in the image. Please try a different image.');
  }

  private extractCropFromDisease(diseaseClass: string): string {
    const diseaseMap: { [key: string]: string } = {
      'corn': 'Maize/Corn',
      'maize': 'Maize/Corn',
      'wheat': 'Wheat',
      'rice': 'Rice',
      'tomato': 'Tomato',
      'cotton': 'Cotton',
      'soybean': 'Soybean',
      'potato': 'Potato'
    };
    
    const lowerClass = diseaseClass.toLowerCase();
    for (const [key, value] of Object.entries(diseaseMap)) {
      if (lowerClass.includes(key)) {
        return value;
      }
    }
    
    return 'Mixed Crop';
  }

  private standardizeDiseaseName(diseaseClass: string): string {
    const diseaseMap: { [key: string]: string } = {
      'healthy': 'Healthy',
      'blight': 'Leaf Blight',
      'rust': 'Rust Disease',
      'spot': 'Leaf Spot',
      'wilt': 'Wilt Disease',
      'mosaic': 'Mosaic Virus',
      'mildew': 'Powdery Mildew',
      'rot': 'Root Rot',
      'bacterial': 'Bacterial Disease',
      'fungal': 'Fungal Disease',
      'viral': 'Viral Disease'
    };
    
    const lowerClass = diseaseClass.toLowerCase();
    for (const [key, value] of Object.entries(diseaseMap)) {
      if (lowerClass.includes(key)) {
        return value;
      }
    }
    
    return diseaseClass
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  private calculateSeverityFromConfidence(confidence: number): 'none' | 'low' | 'medium' | 'high' {
    if (confidence > 90) return 'high';
    if (confidence > 75) return 'medium';
    if (confidence > 60) return 'low';
    return 'low';
  }

  private calculateYieldFromHealth(disease: string, severity: 'none' | 'low' | 'medium' | 'high'): number {
    const baseYield = 4.2;
    const severityMultipliers = {
      'none': 1.0,
      'low': 0.9,
      'medium': 0.75,
      'high': 0.6
    };
    
    const multiplier = severityMultipliers[severity];
    const randomFactor = 0.9 + (Math.random() * 0.2);
    
    return Math.round(baseYield * multiplier * randomFactor * 100) / 100;
  }

  private generateTreatmentRecommendation(disease: string, severity: 'none' | 'low' | 'medium' | 'high', confidence: number): string {
    if (disease === 'Healthy') {
      return 'Excellent! Your crop is in optimal health. Continue current management practices, maintain proper irrigation, and monitor regularly for any changes.';
    }

    const treatmentDatabase: { [key: string]: string } = {
      'leaf blight': 'Apply systemic fungicide containing Chlorothalonil or Mancozeb (2-3 lbs/acre). Remove infected plant material and improve air circulation.',
      'rust disease': 'Apply Propiconazole-based fungicide early morning or evening. Ensure proper plant spacing for air circulation.',
      'leaf spot': 'Apply copper-based fungicide. Remove affected leaves and improve air circulation. Avoid overhead watering.',
      'wilt disease': 'Improve soil drainage immediately. Apply fungicide containing Metalaxyl. Remove severely affected plants.',
      'mosaic virus': 'Remove infected plants immediately. Control aphid vectors with insecticides. Use certified virus-free seeds.',
      'powdery mildew': 'Apply sulfur-based fungicide or Myclobutanil. Improve air circulation and reduce humidity.',
      'bacterial disease': 'Use copper-based bactericides (Copper sulfate 2-3 lbs/acre). Improve field drainage.',
      'fungal disease': 'Apply broad-spectrum fungicide (Mancozeb or Chlorothalonil). Improve drainage and air circulation.',
      'viral disease': 'Remove infected plants immediately. Control insect vectors. Use certified disease-free planting material.'
    };

    const diseaseLower = disease.toLowerCase();
    let treatment = 'Consult with local agricultural extension officer for specific treatment recommendations based on your region and crop variety.';
    
    for (const [key, remedy] of Object.entries(treatmentDatabase)) {
      if (diseaseLower.includes(key.split(' ')[0])) {
        treatment = remedy;
        break;
      }
    }

    const urgencyLevels = {
      'high': 'CRITICAL ACTION REQUIRED: ',
      'medium': 'IMPORTANT: ',
      'low': 'MONITOR CLOSELY: ',
      'none': ''
    };

    const urgency = urgencyLevels[severity];
    const followUp = severity === 'high' 
      ? ' Monitor daily and reapply treatment if symptoms persist after 5-7 days.'
      : severity === 'medium'
      ? ' Check progress in 3-5 days and reapply if necessary.'
      : ' Continue regular monitoring and maintain preventive measures.';
    
    return `${urgency}${treatment}${followUp}`;
  }

  private async imageToBase64(imageElement: HTMLImageElement): Promise<string> {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    const maxSize = 1024;
    const ratio = Math.min(maxSize / imageElement.width, maxSize / imageElement.height);
    
    canvas.width = imageElement.width * ratio;
    canvas.height = imageElement.height * ratio;
    
    if (ctx) {
      ctx.drawImage(imageElement, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
    }
    
    throw new Error('Failed to process image');
  }

  isModelLoaded(): boolean {
    return this.isLoaded;
  }

  getLoadingProgress(): number {
    return this.loadingProgress;
  }
}

export const aiModel = new AgriculturalAIModel();